<?php 

class Events extends CI_Controller {

    public function index()
    {
        $data['events'] = $this->m_events->tampil_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('events', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_aksi()
    {
        $nama_event  = $this->input->post('nama_event');
        $deskripsi   = $this->input->post('deskripsi');
        $tanggal     = $this->input->post('tanggal');

        $data = array(
            'nama_event' => $nama_event,
            'deskripsi'  => $deskripsi,
            'tanggal'    => $tanggal
        );

        $this->m_events->input_data($data, 'events');
        redirect('Events');
    }
}