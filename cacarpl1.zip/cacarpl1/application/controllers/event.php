<?php 

class Event extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_event');
    }

    public function index() {
        $data['event'] = $this->m_event->tampil_data()->result();
        $data['uri1'] = 'event';
        $data['uri2'] = '';
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar', $data);
        $this->load->view('event', $data);
        $this->load->view('templates/footer');
    }

    public function tambah() {
        $data['uri1'] = 'event';
        $data['uri2'] = 'tambah';
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar', $data);
        $this->load->view('tambah_peserta');
        $this->load->view('templates/footer');
    }

    public function tambah_aksi() {
        $nama    = $this->input->post('nama');
        $kelas   = $this->input->post('kelas');
        $event   = $this->input->post('event');
        $phone   = $this->input->post('phone');
        $reason   = $this->input->post('reason');
        

        $data = array(
            'nama'   => $nama,
            'kelas'  => $kelas,
            'event'  => $event,
            'phone'  => $phone,
            'reason' => $reason,
        );

        $this->m_event->input_data($data, 'peserta');
        redirect('event');
    }
public function hapus ($id)
{
$where = array ('id' => $id);
$this->m_event->hapus_data($where,'peserta');
redirect ('event/index');
    }
public function edit($id)
{
  $where = array ('id' => $id);
  $data['event'] = $this->m_event->edit_data($where,'peserta')->result();

$this->load->view('templates/header');
$this->load->view('templates/sidebar', $data);
$this->load->view('edit', $data);
$this->load->view('templates/footer');

  }

public function update(){
$id = $this->input->post('id');
$nama = $this->input->post('nama');
$kelas = $this->input->post('kelas');
$event = $this->input->post('event');
$phone = $this->input->post('phone');
$reason = $this->input->post('reason');
 $data = array(
 'nama' => $nama,
 'kelas' => $kelas,
 'event' => $event,
 'phone' => $phone,
 'reason' => $reason
    );
  $where = array(
    'id' => $id
   );
  $this->m_event->update_data($where,$data,'peserta');
 redirect('event/index');
  }

}