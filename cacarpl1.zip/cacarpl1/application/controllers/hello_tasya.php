<?php 

class Hello_Tasya extends CI_Controller{

  public function index () {
  $this->load->model('m_biodata');
  $data['biodata']=
  $this->m_biodata->get_data();  
  $this->load->view('v_biodata', $data);   
 }
  }

 