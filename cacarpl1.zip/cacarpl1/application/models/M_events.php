<?php 

class M_events extends CI_Model {
  
    public function tampil_data()
    {
        return $this->db->get('events');
    }

    public function input_data($data, $table)
    {
        $this->db->insert($table, $data);
    }
}