<?php 


class M_biodata extends CI_model{
 public function get_data ()
{
return $this->db->get('tb_biodata')->result_array();
 }
}


 ?>