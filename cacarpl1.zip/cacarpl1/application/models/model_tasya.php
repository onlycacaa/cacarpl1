<?php 

class model_tasya extends CI_Model {
public function get_data()
{
}
}

 ?>