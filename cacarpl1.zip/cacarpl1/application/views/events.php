<div class="content-wrapper">
  <section class="content-header">
    <h1>
      Classmeeting
    </h1>
    <ol class="breadcrumb">
      <li class="active">Data Events</li>
    </ol>
  </section>

  <section class="content">
    <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Tambah Data Event</button>
    <table class="table">
      <tr>
        <th>NO</th>
        <th>NAMA EVENT</th>
        <th>DESKRIPSI</th>
        <th>TANGGAL</th>
      </tr>

      <?php  
      $no = 1;
      foreach ($events as $row) : ?>
        <tr>
          <td><?php echo $no++ ?></td>
          <td><?php echo $row->nama_event ?></td>
          <td><?php echo $row->deskripsi ?></td>
          <td><?php echo $row->tanggal ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  </section>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"> 
    <div class="modal-dialog" role="document">
      <div class="modal-content"> 
        <div class="modal-header"> 
          <h4 class="modal-title" id="exampleModalLabel">FORM INPUT DATA EVENT</h4> 
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button> 
        </div> 
        <div class="modal-body"> 

          <form method="post" action="<?php echo base_url().'index.php/Events/tambah_aksi'; ?>">

            <div class="form-group">
              <label>Nama Event</label>
              <input type="text" name="nama_event" class="form-control">
            </div>

            <div class="form-group">
              <label>Deskripsi</label>
              <input type="text" name="deskripsi" class="form-control">
            </div>

            <div class="form-group">
              <label>Tanggal</label>
              <input type="date" name="tanggal" class="form-control">
            </div>

            <button type="reset" class="btn btn-danger" data-bs-dismiss="modal">Reset</button>
            <button type="submit" class="btn btn-primary">Simpan</button>

          </form>
        </div> 
      </div> 
    </div> 
  </div>
</div>