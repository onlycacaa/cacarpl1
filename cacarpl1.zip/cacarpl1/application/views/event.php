<div class="dashboard-wrapper">
   <div class="dashboard-ecommerce"> 
      <div class="container-fluid dashboard-content">
         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="page-header">
                  <h2 class="pageheader-title">Classmeet SMK BINA CENDEKIA</h2>
                  <div class="page-breadcrumb">
                     <nav aria-label="breadcrumb">
                        <ol class="breadcrumb"></ol>
                     </nav>
                  </div>
<div class="content-wrapper">
  <section class="content-header">
    <h1>Classmeeting</h1>
  </section>

  <section class="content">
    <a href="<?php echo site_url('event/tambah'); ?>">Data Peserta</a>
    <br><br>
    <table class="table">
      <tr>
        <th>NO</th>
        <th>NAMA</th>
        <th>KELAS</th>
        <th>EVENT</th>
        <th>NO HP</th>
        <th>ALASAN</th>
        <th colspan="2">AKSI</th>
      </tr>
      <?php $no = 1; foreach ($event as $row): ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $row->nama; ?></td>
        <td><?php echo $row->kelas; ?></td>
        <td><?php echo $row->event; ?></td>
        <td><?php echo $row->phone; ?></td>
        <td><?php echo $row->reason; ?></td>
        <td onclick="javascript: return confirm('Anda yakin hapus?')"><?php echo anchor('event/hapus/'.$row->id,'<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>
        <td><?php echo anchor('event/edit/'.$row->id,'<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>') ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </section>
</div>