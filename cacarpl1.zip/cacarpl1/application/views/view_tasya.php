<!DOCTYPE html>
<html>
<head>
    <title>Contoh View</title>
</head>
<body>

   <h1>Belajar adalah proses yang tidak pernah berhenti</h1>
   <hr>
   <p>Teruslah bertanya,teruslah mencari dan teruslah tumbuh</p>

</body>
</html>