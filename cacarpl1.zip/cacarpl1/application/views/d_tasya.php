<div class="dashboard-wrapper">
   <div class="dashboard-ecommerce"> 
      <div class="container-fluid dashboard-content">
         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="page-header">
                  <h2 class="pageheader-title">Classmeet SMK BINA CENDEKIA</h2>
                  <div class="page-breadcrumb">
                     <nav aria-label="breadcrumb">
                        <ol class="breadcrumb"></ol>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
         <div class="ecommerce-widget">
            <div class="row">
               <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                  <div class="card">
                     <div class="card-body">
                        <h5 class="text-muted">Total Participants</h5>
                        <div class="metric-value d-inline-block">
                           <h1 class="mb-1">678</h1>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                  <div class="card">
                     <div class="card-body">
                        <h5 class="text-muted">Total Events</h5>
                        <div class="metric-value d-inline-block">
                           <h1 class="mb-1">12</h1>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                  <div class="card">
                     <div class="card-body">
                        <h5 class="text-muted">Upcoming Event</h5>
                        <div class="metric-value d-inline-block">
                           <h2 class="mb-1">Classmeeting</h2>
                        </div>
                        <div class="metric-label d-inline-block float-right text-primary font-weight-bold">
                           <span>Des 26</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>