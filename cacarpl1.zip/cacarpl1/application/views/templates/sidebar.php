
    
<?php 
$uri = $this->uri->segment(1);
$method = $this->uri->segment(2);
?>
<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">MENU</li>

                    <!-- Menu Dashboard -->
                    <li class="nav-item">
                        <a href="<?php echo site_url('admin'); ?>" 
                           class="nav-link <?= ($uri == 'admin') ? 'active' : '' ?>">
                            <i class="fa fa-fw fa-tachometer-alt"></i>Dashboard
                        </a>
                    </li>

                    <!-- Menu Daftar Peserta -->
                    <li class="nav-item">
                        <a class="nav-link <?= ($uri == 'event') ? 'active' : '' ?>" href="#" data-toggle="collapse" 
                           aria-expanded="<?= ($uri == 'event') ? 'true' : 'false' ?>" 
                           data-target="#submenu-1" aria-controls="submenu-1">
                            <i class="fa fa-fw fa-users"></i>Daftar Peserta
                        </a>
                        <div id="submenu-1" class="collapse submenu <?= ($uri == 'event') ? 'show' : '' ?>">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link <?= ($uri == 'event' && $method == '') ? 'active' : '' ?>" 
                                       href="<?php echo site_url('event'); ?>">List Peserta</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?= ($uri == 'event' && $method == 'tambah') ? 'active' : '' ?>" 
                                       href="<?php echo site_url('event/tambah'); ?>">Pendaftaran</a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <!-- Menu Daftar Events -->
                    <li class="nav-item">
                        <a class="nav-link <?= ($uri == 'events') ? 'active' : '' ?>" href="#" data-toggle="collapse" 
                           aria-expanded="<?= ($uri == 'events') ? 'true' : 'false' ?>" 
                           data-target="#submenu-2" aria-controls="submenu-2">
                            <i class="fa fa-fw fa-calendar"></i>Daftar Events
                        </a>
                        <div id="submenu-2" class="collapse submenu <?= ($uri == 'events') ? 'show' : '' ?>">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="#">List Events</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Tambah Events</a>
                                </li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>