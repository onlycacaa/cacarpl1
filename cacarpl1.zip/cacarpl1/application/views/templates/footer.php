</div> <!-- container-fluid -->
      </div> <!-- dashboard-ecommerce -->
    </div> <!-- dashboard-wrapper -->

    <div class="footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            Copyright © 2018 Concept. All rights reserved.
            Dashboard by <a href="https://colorlib.com/wp/">Colorlib</a>.
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="text-md-right footer-links d-none d-sm-block">
              <a href="javascript: void(0);">About</a>
              <a href="javascript: void(0);">Support</a>
              <a href="javascript: void(0);">Contact Us</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo base_url('assets/vendor/jquery/jquery-3.3.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/slimscroll/jquery.slimscroll.js'); ?>"></script>
    <script src="<?php echo base_url('assets/libs/js/main-js.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/chartist-bundle/chartist.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/sparkline/jquery.sparkline.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/morris-bundle/raphael.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/morris-bundle/morris.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/c3charts/c3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/c3charts/d3-5.4.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor/charts/c3charts/C3chartjs.js'); ?>"></script>
    <script src="<?php echo base_url('assets/libs/js/dashboard-ecommerce.js'); ?>"></script>
  </body>
</html>