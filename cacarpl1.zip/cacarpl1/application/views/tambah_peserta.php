<div class="dashboard-wrapper">
   <div class="dashboard-ecommerce"> 
      <div class="container-fluid dashboard-content">
         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="page-header">
                  <h2 class="pageheader-title">Classmeet SMK BINA CENDEKIA</h2>
                  <div class="page-breadcrumb">
                     <nav aria-label="breadcrumb">
                        <ol class="breadcrumb"></ol>
                     </nav>
                  </div>

<div class="content-wrapper">
  <section class="content-header">
    <h1>Formulir Pendaftaran</h1>
  </section>

  <section class="content">
    <form method="post" action="<?php echo base_url('index.php/event/tambah_aksi'); ?>">
      <div class="form-group">
        <label>Nama Peserta</label>
        <input type="text" name="nama" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Kelas</label>
        <input type="text" name="kelas" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Event</label>
        <select name="event" class="form-control" required>
          <option value="Lomba Futsal">Lomba Futsal</option>
          <option value="Lomba Basket">Lomba Basket</option>
          <option value="Lomba Voli">Lomba Voli</option>
          <option value="Lomba Tari">Lomba Tari</option>
          <option value="Cerdas Cermat">Cerdas Cermat</option>
        </select>
      </div>
      <div class="form-group">
        <label>Phone</label> 
 <input type="text" name="phone" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Reason</label>
        <textarea name="reason" class="form-control" required></textarea>
      </div>
      <button type="reset" class="btn btn-danger">Reset</button>
      <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
  </section>
</div>