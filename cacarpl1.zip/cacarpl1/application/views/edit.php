<div class="dashboard-wrapper">
   <div class="dashboard-ecommerce"> 
      <div class="container-fluid dashboard-content">
         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
               <div class="page-header">
                  <h2 class="pageheader-title">Classmeet SMK BINA CENDEKIA</h2>
                  <div class="page-breadcrumb">
                     <nav aria-label="breadcrumb">
                        <ol class="breadcrumb"></ol>
                     </nav>
                  </div>
<div class="content-wrapper">
 <section class="content">
   <?php foreach($event as $row) { ?>
<form action="<?php echo site_url('Event/update'); ?>" method="post">
  <div class="form-group">
  <label>Nama</label>
  <input type="hidden" name="id" class="form-control" value="<?php echo $row->id ?>">
  <input type="text" name="nama" class="form-control" value="<?php echo $row->nama ?>">
</div>

   <div class="form-group">
  <label>Kelas</label>
  <input type="text" name="kelas" class="form-control" value="<?php echo $row->kelas ?>">
</div>

   <div class="form-group">
  <label>Event</label>
  <select class="form-control" name="event" value="<?php echo $row->event ?>">
  <option>Lomba Futsal</option>
  <option>Lomba Basket</option>
  <option>Lomba Voli</option>
  <option>Lomba Tari</option>
  <option>Cerdas Cermat</option>
</select>
</div>

    <div class="form-group">
  <label>Phone</label>
  <input type="text" name="phone" class="form-control" value="<?php echo $row->phone ?>">
</div>

    <div class="form-group">
  <label>Alasan</label>
  <input type="text" name="reason" class="form-control" value="<?php echo $row->reason ?>">
</div>

<button type="submit" class="btn btn-danger">Reset</button>

<button type="submit" class="btn btn-primary">Simpan</button>

</form>
   <?php } ?>
</section>
</div>